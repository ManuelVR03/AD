package com.ejemplos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiRestVersion0124ApplicationTests {

	@Test
	void contextLoads() {
	}

}
