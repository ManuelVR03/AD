package com.ejemplos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiRestVersion0124Application {

	public static void main(String[] args) {
		SpringApplication.run(ApiRestVersion0124Application.class, args);
	}

}
