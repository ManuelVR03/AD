package com.ejemplos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ManuelVerdejoRamirezAdEv2ConsumoApplicationTests {

	@Test
	void contextLoads() {
	}

}
