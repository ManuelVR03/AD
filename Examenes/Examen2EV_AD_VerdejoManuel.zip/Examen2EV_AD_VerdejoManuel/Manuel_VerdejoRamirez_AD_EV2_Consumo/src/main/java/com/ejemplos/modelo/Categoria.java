package com.ejemplos.modelo;

import lombok.Data;

@Data
public class Categoria {

	private Long idCat;
	private String nombre;
}
